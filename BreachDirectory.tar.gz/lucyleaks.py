print('''
██▓     █    ██  ▄████▄  ▓██   ██▓ ██▓    ▓█████  ▄▄▄       ██ ▄█▀  ██████ 
▓██▒     ██  ▓██▒▒██▀ ▀█   ▒██  ██▒▓██▒    ▓█   ▀ ▒████▄     ██▄█▒ ▒██    ▒ 
▒██░    ▓██  ▒██░▒▓█    ▄   ▒██ ██░▒██░    ▒███   ▒██  ▀█▄  ▓███▄░ ░ ▓██▄   
▒██░    ▓▓█  ░██░▒▓▓▄ ▄██▒  ░ ▐██▓░▒██░    ▒▓█  ▄ ░██▄▄▄▄██ ▓██ █▄   ▒   ██▒
░██████▒▒▒█████▓ ▒ ▓███▀ ░  ░ ██▒▓░░██████▒░▒████▒ ▓█   ▓██▒▒██▒ █▄▒██████▒▒
░ ▒░▓  ░░▒▓▒ ▒ ▒ ░ ░▒ ▒  ░   ██▒▒▒ ░ ▒░▓  ░░░ ▒░ ░ ▒▒   ▓▒█░▒ ▒▒ ▓▒▒ ▒▓▒ ▒ ░
░ ░ ▒  ░░░▒░ ░ ░   ░  ▒    ▓██ ░▒░ ░ ░ ▒  ░ ░ ░  ░  ▒   ▒▒ ░░ ░▒ ▒░░ ░▒  ░ ░
  ░ ░    ░░░ ░ ░ ░         ▒ ▒ ░░    ░ ░      ░     ░   ▒   ░ ░░ ░ ░  ░  ░  
    ░  ░   ░     ░ ░       ░ ░         ░  ░   ░  ░      ░  ░░  ░         ░  
                 ░         ░ ░                                              
''')

import http.client
from urllib.parse import quote
import json
import time

# Definir códigos de escape ANSI para cores RGB
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
BLUE = "\033[94m"
MAGENTA = "\033[95m"
CYAN = "\033[96m"
RESET = "\033[0m"

def consultar_brecha(email):
    # Substitua "SUA-CHAVE-DE-API-AQUI" pela sua chave de API do RapidAPI
    api_key = "23c1a6794emsh2ea55047f98ecb5p1743fbjsn4e3143495981"
    
    while True:
        # Configurar a conexão com a API
        conn = http.client.HTTPSConnection("api.breachdirectory.org")

        # Codificar o email para ser usado na URL
        email_encoded = quote(email)

        # Construir o caminho para a consulta com o email fornecido
        path = f"/rapidapi-IscustemTaingtowItrionne?func=auto&term={email_encoded}"

        # Configurar os headers com a chave da API e User-Agent
        headers = {
            'X-RapidAPI-Key': api_key,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }

        # Fazer a requisição GET
        conn.request("GET", path, headers=headers)

        # Obter a resposta da requisição
        res = conn.getresponse()

        # Verificar se a resposta foi bem-sucedida (código 200) ou redirecionamento (código 302)
        if res.status == 200:
            # Ler e decodificar os dados JSON
            data = res.read()
            json_data = json.loads(data.decode("utf-8"))

            # Exibir os resultados formatados
            exibir_resultados(json_data)
            break
        elif res.status == 302:
            # Lidar com redirecionamento
            location = res.getheader('Location')
            print(f'Redirecionando para: {location}')
            path = location  # Atualizar o caminho com a nova localização
        elif res.status == 429:
            print("Limite de taxa atingido. Aguardando antes de tentar novamente.")
            time.sleep(60)  # Aguardar 1 minuto antes de tentar novamente
        else:
            # Imprimir uma mensagem de erro caso a resposta não seja bem-sucedida
            print(f"Erro na requisição. Código de status: {res.status}")
            break

def exibir_resultados(json_data):
    if "result" in json_data and isinstance(json_data["result"], list):
        resultados = json_data["result"]
        
        for i, resultado in enumerate(resultados, start=1):
            print("========================")
            print(f"Resultado ({str(i).zfill(2)})")
            exibir_detalhes_resultado(resultado)

def exibir_detalhes_resultado(resultado):
    exibir_item("Email", resultado.get("email"), RED)
    exibir_item("Senha", resultado.get("password"), GREEN)
    exibir_item("Hash", resultado.get("hash"), YELLOW)
    exibir_item("sha1", resultado.get("sha1"), BLUE)
    exibir_item("Sources", ", ".join(resultado.get("sources", [])), MAGENTA)

def exibir_item(nome, valor, cor):
    if valor is not None:
        print(f"{cor}{nome}: \"{valor}\"{RESET}")

# Solicitar o e-mail ao usuário
email_para_consultar = input("Digite o e-mail para consultar: ")
consultar_brecha(email_para_consultar)

# Adicionar a mensagem de desenvolvedor abaixo do script
print("\nDesenvolvido por David A. Mascaro")
